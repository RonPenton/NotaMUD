import React from "react";

export const Icon: React.SFC = () => {
    return <img src={"./icons/battle-axe.svg"} />
}
