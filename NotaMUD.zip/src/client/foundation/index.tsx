export type Size = "tiny" | "small" | "medium" | "large";

export type Status = "primary" | "secondary" | "success" | "alert" | "warning";