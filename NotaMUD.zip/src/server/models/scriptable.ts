export type Scriptable = {
    data: { [index: string]: any }
}