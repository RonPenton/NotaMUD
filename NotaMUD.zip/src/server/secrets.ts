import config from './config';

export const secrets = {
    cookieSecret: "the rain in spain falls mainly on the spaniards",
    AWSConfig: {
        accessKeyId: "AKIAISPN6P3OHVW3YQHA",
        secretAccessKey: "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",
        region: config.AWSRegion   
    }
}

export default secrets;


