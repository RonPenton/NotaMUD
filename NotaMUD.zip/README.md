# NotaMUD

This is NotaMUD, which might be a MUD one day, but currently is not. And it may never be. But it thinks it might be. 

It runs in Node and uses WebSockets. Why, idk. But it does. 

# Setup

```
npm install
npm run build
npm run-script go
```
